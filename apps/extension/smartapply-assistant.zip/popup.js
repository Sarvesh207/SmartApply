"use strict";
// SmartApply Assistant Popup Script
Object.defineProperty(exports, "__esModule", { value: true });
document.addEventListener('DOMContentLoaded', async () => {
    const connectionStatusEl = document.getElementById('connection-status');
    const currentPortalEl = document.getElementById('current-portal');
    const formStatusEl = document.getElementById('form-status');
    const autofillBtn = document.getElementById('autofill-btn');
    const feedbackEl = document.getElementById('feedback-msg');
    let userProfile = null;
    let activeTabId = null;
    // 1. Check Server Connection & Authentication
    chrome.runtime.sendMessage({ type: 'CHECK_AUTH' }, (response) => {
        if (chrome.runtime.lastError) {
            console.warn('Background worker connection failed:', chrome.runtime.lastError);
            connectionStatusEl.textContent = 'Server Offline (Local Presets)';
            connectionStatusEl.parentElement?.querySelector('.dot')?.classList.remove('active');
            connectionStatusEl.parentElement?.querySelector('.dot')?.classList.add('warning');
            return;
        }
        if (response && response.authenticated) {
            userProfile = response.user;
            connectionStatusEl.textContent = `Connected: ${userProfile.email}`;
            // Sync local profile with backend if available
            syncProfileWithBackend();
        }
        else {
            connectionStatusEl.textContent = 'Guest Mode (Local Presets)';
            connectionStatusEl.parentElement?.querySelector('.dot')?.classList.remove('active');
            connectionStatusEl.parentElement?.querySelector('.dot')?.classList.add('warning');
        }
    });
    // 2. Query Active Tab status
    const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (activeTab && activeTab.id) {
        activeTabId = activeTab.id;
        // Send message to Content Script on active tab to check page status
        chrome.tabs.sendMessage(activeTab.id, { type: 'GET_PAGE_STATUS' }, (response) => {
            if (chrome.runtime.lastError) {
                // Content script didn't load (unsupported scheme like chrome:// or extension context)
                currentPortalEl.textContent = 'Unsupported Page';
                formStatusEl.textContent = 'Scanner Unavailable';
                autofillBtn.disabled = true;
                return;
            }
            if (response) {
                currentPortalEl.textContent = response.portal || 'Unknown';
                if (response.formDetected) {
                    formStatusEl.textContent = 'Form Detected';
                    formStatusEl.className = 'value success';
                    autofillBtn.disabled = false;
                }
                else {
                    formStatusEl.textContent = 'No form detected';
                    formStatusEl.className = 'value warning';
                    // Enable autofill anyway so users can force try it on general pages
                    autofillBtn.disabled = false;
                }
            }
        });
    }
    // 3. Sync profile with backend data
    function syncProfileWithBackend() {
        chrome.runtime.sendMessage({ type: 'FETCH_RESUME' }, (response) => {
            if (response && response.success && response.resume) {
                const resume = response.resume;
                chrome.storage.local.get(['autofillProfile'], (result) => {
                    const current = result.autofillProfile || {};
                    const updated = {
                        ...current,
                        email: userProfile?.email || current.email,
                        // Simple mapping from parsed skills if available
                        location: resume.location || current.location || 'India',
                    };
                    chrome.storage.local.set({ autofillProfile: updated });
                });
            }
        });
    }
    // 4. Handle Autofill click
    autofillBtn.addEventListener('click', () => {
        if (!activeTabId)
            return;
        autofillBtn.disabled = true;
        feedbackEl.textContent = 'Scanning and filling fields...';
        feedbackEl.className = 'feedback';
        chrome.storage.local.get(['autofillProfile'], (result) => {
            const profile = result.autofillProfile;
            if (!profile) {
                feedbackEl.textContent = 'No profile presets found.';
                feedbackEl.className = 'feedback error';
                autofillBtn.disabled = false;
                return;
            }
            chrome.tabs.sendMessage(activeTabId, { type: 'START_AUTOFILL', profile }, (response) => {
                autofillBtn.disabled = false;
                if (chrome.runtime.lastError) {
                    feedbackEl.textContent = 'Could not communicate with tab.';
                    feedbackEl.className = 'feedback error';
                    return;
                }
                if (response && response.success) {
                    feedbackEl.textContent = `Autofilled ${response.filledCount} fields!`;
                    feedbackEl.className = 'feedback success';
                }
                else {
                    feedbackEl.textContent = response?.error || 'Autofill failed.';
                    feedbackEl.className = 'feedback error';
                }
            });
        });
    });
});
